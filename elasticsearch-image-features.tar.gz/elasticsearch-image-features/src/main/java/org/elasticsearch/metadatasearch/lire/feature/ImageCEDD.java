package org.elasticsearch.metadatasearch.lire.feature;

import net.semanticmetadata.lire.utils.SerializationUtils;
import org.elasticsearch.metadatasearch.similarity.CosineSimilarity;

import net.semanticmetadata.lire.imageanalysis.CEDD;

public class ImageCEDD extends CEDD implements ImageLireFeature{
	protected byte[] histogram_davi = new byte[12292];

    @Override
    public double[] getDoubleHistogram() {
        return SerializationUtils.castToDoubleArray(this.histogram_davi);
    }

	public void setHistogramFromDoubleArray(double[] h)
	    {
	         for (int i = 0; i < h.length; i++) {
	             histogram_davi[i] = (byte) h[i];
	         }
	         
	    }

	@Override
	public float getSimilarity(ImageLireFeature ilf) {
		 return CosineSimilarity.cosineSimilarity(this.getDoubleHistogram(), ilf.getDoubleHistogram());
		
	}
}
